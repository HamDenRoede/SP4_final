import org.w3c.dom.ls.LSOutput;

import java.util.*;


public class Console  //Author: Jonas & Ole & Nicholas & Kim

{
    Scanner sc = new Scanner(System.in);
    PizzaMenu pm = new PizzaMenu();
    int o_number = 0;
    boolean running = true;
    boolean completed = false;
    int orderNumber = 0;
    ArrayList<Order> orders = new ArrayList<Order>();
    DBBasicMethods DBB = new DBBasicMethodsMySqlImpl();
    double totalPrice;
    int p = 1;

    public void addOrder(Order a)
    {
        orders.add(a);
    }

    public void startConsole()
    {
        pm.start();


        while (running)
        {
            System.out.println(
                    "\n " +
                            "\n " +
                            "\nMario's Pizzabar" +
                            "\n----------------" +
                            "\n1) Show Menu" +
                            "\n2) Create order" +
                            "\n3) Edit orders" +
                            "\n4) Show: End of day" +
                            "\n0) Exit" +
                            "\n----------------" +
                            "\n(Please choose an option)");

            String cmd = sc.nextLine();
            if (cmd.equals("1"))
            {
                System.out.println(" 1.  Vesuvio:      tomatsauce, ost, skinke og oregano                             -  57,-\n" +
                        " 2.  Amerikaner:   tomatsauce, ost, oksefars og oregano                           -  53,-\n" +
                        " 3.  Cacciatora:   tomatsauce, ost, pepperoni og oregano                          -  57,-\n" +
                        " 4.  Carbona:      tomatsauce, ost, kødsauce, spghetti, coktailpølser og oregano  -  63,-\n" +
                        " 5.  Dennis:       tomatsauce, ost, bacon og oregano                              -  65,-\n" +
                        " 6.  Bertil:       tomatsauce, ost, bacon og oregano                              -  57,-\n" +
                        " 7.  Silvia:       tomatsauce, ost, pepperoni, rød peber, løg, oliven og oregano  -  61,-\n" +
                        " 8.  Victoria:     tomatsauce, ost, skinke, ananas, champignon, løg og oregano    -  61,-\n" +
                        " 9.  Toronfo:      tomatsauce, ost, skinke, bacon, kebab, chili og oregano        -  61,-\n" +
                        " 10. Capricciosa:  tomatsauce, ost, skinke, champignon og oregano                 -  61,-\n" +
                        " 11. Hawai:        tomatsauce, ost, skinke, ananas og oregano                     -  61,-\n" +
                        " 12. Le Blissola:  tomatsauce, ost, skinke, rejer og oregano                      -  61,-\n" +
                        " 13. Venezia:      tomatsauce, ost, skinke, bacon og oregano                      -  61,-\n" +
                        " 14. Mafia:        tomatsauce, ost, pepperoni, bacon, løg og oregano");
            }
            if (cmd.equals("2"))
            {
                int pizzaNr = 0;
                int pickUpTime = -1;
                o_number++;
                do
                {
                    pizzaNr = intValidation("Input desired pizza - end order with 0", 0, 14);

                    if (pickUpTime == -1)
                    {
                        pickUpTime = intValidation("Type pickup time, use military time ie. 1930", 0, 2359);
                    }
                    if (pizzaNr != 0)
                    {
                        DBB.insertSingle(o_number, pizzaNr, pickUpTime, false, pm.pizzaMenu.get(pizzaNr).getPrice());
                    }
                } while (pizzaNr != 0);
                System.out.println("total order price: " + DBB.totalOrderValue(o_number));
                cmd = sc.nextLine();
                /*
                System.out.println("type pickup time, use military time ie. 1930");
                int pickUpTime = sc.nextInt();
                double totalPrice = 0;
                System.out.println("Input desired pizzas, separated by space");
                String d = sc.nextLine();
                String pizzas = sc.nextLine();
                o_number++;
                String[] temp = pizzas.split(" ", 50); // String temp[pizzas]
                for (int i = 0; i < temp.length; i++)
                {
                    int tempNumb = Integer.parseInt(temp[i]) - 1;
                    totalPrice += pm.pizzaMenu.get(tempNumb).getPrice();
                    //Order o = new Order(p ,tempNumb, pickUpTime, false, totalPrice);
                    tempNumb++;
                    DBB.insertSingle(o_number ,tempNumb, pickUpTime, false, totalPrice);

                }





                //orders.add(o);
                System.out.println(orders);
                cmd = "0";
                p++;*/
            }
            if (cmd.equals("3"))
            {
                System.out.println(
                        "\n " +
                                "\n----------------" +
                                "\n1) Show all orders" +
                                "\n2) Complete order" +
                                "\n3) Show unfinnished orders" +
                                "\n4) Delete orders" +
                                "\n----------------" +
                                "\n(Please choose an option 1-4)");
                cmd = sc.nextLine();
                if (cmd.equals("1"))
                {
                    System.out.println("Showing orders");
                    DBB.printOrders();
                }
                if (cmd.equals("2"))
                {
                    System.out.println("Showing orders");
                    DBB.printOrders();
                    System.out.println("Select order to complete");
                    orderNumber = sc.nextInt();
                    DBB.completeOrder(orderNumber);
                    System.out.println("Order completed!");
                    cmd = sc.nextLine();
                }
                if (cmd.equals("3"))
                {
                    System.out.println("Showing all unfinished orders:");
                    for (Order s : orders)
                    {
                        if (s.completed = false)
                            System.out.println(s);
                    }
                    cmd = sc.nextLine();
                }
                if (cmd.equals("4"))
                {
                    System.out.println("Showing orders");
                    DBB.printOrders();
                    System.out.println("What number to delete?");
                    orderNumber = sc.nextInt();
                    DBB.deleteSingle(orderNumber);
                    System.out.println("Order deleted!");
                    cmd = sc.nextLine();
                }
                if (cmd.equals("0"))
                {
                    running = false;
                }
            }
            if (cmd.equals("0"))
            {
                running = false;
            }
        }
    }
    int intValidation(String question ,int min, int max)
    {
        int input = 0;
        System.out.println(question);
        boolean exitLoop = false;
        do
        {
            input = sc.nextInt();
            if (input < min || input > max)
            {
                System.out.println("invalid input please specify a number between " + min + " and " + max);
                exitLoop = false;
            } else
            {
                exitLoop = true;

            }
        } while (exitLoop == false);
        return input;
    }
}

