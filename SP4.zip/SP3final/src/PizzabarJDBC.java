
import java.sql.*;
import java.util.ArrayList;

public class PizzabarJDBC
{
}


//  insertOrder(order), removeOrder, selectOrder(update), selectAll ?!?,

/*
    public interface DBBasicMethods {
    int deleteSingle(int id);
    Pizza selectSingle(int id);
    int updateSingle(int id, Pizza pizza);
    int insertSingle(Pizza pizza);
    ArrayList<Pizza> selectAll();
}
*/