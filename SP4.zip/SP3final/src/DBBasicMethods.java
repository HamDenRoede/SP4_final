import java.sql.ResultSet;
import java.util.ArrayList;

public interface DBBasicMethods {               //sort function i sql til sout  (alle)
    int deleteSingle(int id);       //Jonas   (delete uden at delete)
    Order selectSingle(int id);     //Nicholas sout (se på en ordre, print ordren)
    int completeOrder(int orderNr); //Kim  (evt. boolean complete update)  UPDATE pizzabar.pizza_orders SET comp = TRUE WHERE oid = ?;
    int insertSingle(int orderNr, int pizza, int pickUpTime, boolean completed, double pizza_price); //Ole
    double totalOrderValue(int orderNr);
    String printOrders();
    //ArrayList<Order> endOfDay();

    ArrayList<Pizza> selectAll();   //sout  Ole
}
