import java.sql.*;
import java.util.ArrayList;
public class DBBasicMethodsMySqlImpl implements DBBasicMethods {

    private Connection connection;
    private String driverName = "com.mysql.cj.jdbc.Driver";
    private PreparedStatement pstmt = null;

    public DBBasicMethodsMySqlImpl() {
        try {
            this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/pizzabar", "root", "slowny");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public int deleteSingle(int orderNr)
    {
        try
        {
            String sql = "DELETE FROM pizza_orders WHERE oid=?";

            pstmt = this.connection.prepareStatement(sql);
            pstmt.setInt(1,orderNr);
            pstmt.executeUpdate();

        }

        catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }
        return 0;
    }


    @Override
    public Order selectSingle(int id) { return null;} /*
        Order o = new Order();

        try{
            String sql = "SELECT * FROM pizzaer WHERE pid=?";

            pstmt = this.connection.prepareStatement(sql);
            pstmt.setInt(1,id);

            ResultSet rs = pstmt.executeQuery();
            rs.next();

            o.orderNr(rs.getInt("oid"));
            o.(rs.getInt("pid"));
            o.setPris(rs.getString("pris"));

            rs.close();
            pstmt.close();

        }catch(Exception e){
            System.out.println(e);
        }

        return p;

    }*/

    @Override
    public int completeOrder(int orderNr)
    {
        try
        {
            String sql = "UPDATE pizzabar.pizza_orders SET comp = TRUE WHERE oid = ?";

            pstmt = this.connection.prepareStatement(sql);
            pstmt.setInt(1,orderNr);
            pstmt.executeUpdate();

        }

        catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }
        return 0;
    }

    @Override
    public String printOrders ()
    {
        try
        {
            String sql = "SELECT *  FROM pizza_orders";

            pstmt = this.connection.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while(rs.next())
            {
                System.out.println("orderNr: "+rs.getInt("oid")+", pizzaId: "+rs.getInt("pid")+"pickUpTime: "+rs.getInt("pid")+", completed? "+rs.getBoolean("comp"));
            }
            rs.close();
        }

        catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }
        return "0";
    }


    public int insertSingle(int orderNr, int pizza, int pickUpTime, boolean completed, double pizza_price)
    {

        String sql = "INSERT INTO pizza_orders (oid, pid, put, comp, pizza_price) VALUES (?, ?, ?, ?, ?)";
        try
        {

            pstmt = this.connection.prepareStatement(sql);
            pstmt.setInt(1,orderNr);
            pstmt.setInt(2,pizza);
            pstmt.setInt(3,pickUpTime);
            pstmt.setBoolean(4,completed);
            pstmt.setDouble(5,pizza_price);
            pstmt.executeUpdate();

        } catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }


        return 0;
    }
    public double totalOrderValue(int orderNr)
    {

        String sql = "SELECT SUM(pizza_price) AS total_price FROM pizzabar.pizza_orders WHERE oid = ?";
        double totalPrice = 0;
        try
        {

            pstmt = this.connection.prepareStatement(sql);
            pstmt.setInt(1,orderNr);
            ResultSet rs = pstmt.executeQuery();
            rs.next();
            totalPrice = rs.getDouble("total_price");

        } catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }


        return totalPrice;
    }
    /*public ArrayList<Order> endOfDay()
    {
        ArrayList<Order> endOfDayOrder = new ArrayList<Order>();
        String sql = "SELECT * FROM pizzabar.pizza_orders WHERE comp = TRUE ORDER BY oid";
        try
        {

            pstmt = this.connection.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            double totalPrice = 0;
            int currentOrderId = 0;
            while(rs.next())
            {
                int orderId = rs.getInt("oid");
                int pickUpTime = rs.getInt("put");
                int pizzaId = rs.getInt("pid");
                double pizzaPrice = rs.getDouble("pizza_price");
                Order order = new Order(orderId,pickUpTime,true,0);
                if(orderId == currentOrderId)
                {
                    totalPrice += pizzaPrice;
                    order.addPizza(pizzaId);
                }
                else
                currentOrderId = orderId;
                totalPrice = 0;
                Order order = new Order(orderId,);  //NEEDS HELP

            }
            do
            {
                int pizzaId = rs.getInt("pid");
                double pizzaPrice = rs.getDouble("pizza_price");
                currentOrderId = rs.getInt("oid");


            }while(orderId == currentOrderId);


            while(rs.next()){
                int ordreId = rs.getInt("oid");
                int pizzaId = rs.getInt("pid");
                double pizzaPrice = rs.getDouble("pizza_price");
                int pickUpTime = rs.getInt("put")
                Order order = new Order(,pickUpTime,true,);

            }


        } catch (SQLException throwables)
        {
            throwables.printStackTrace();
            endOfDayOrder = new ArrayList<Order>();
        }

        return endOfDayOrder;

    }
    */


    @Override
    public ArrayList<Pizza> selectAll() {
        return null;
    }


}
